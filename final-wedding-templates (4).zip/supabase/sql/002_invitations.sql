-- ============================================================================
-- 002_invitations.sql
-- Run after 001_profiles.sql.
--
-- Reference schema for invitations and RSVPs living in Supabase Postgres,
-- with Row Level Security: owners manage their own invitation, anyone can
-- read a published invitation (guests browsing a shared link do not log
-- in), and anyone can submit an RSVP to a published invitation.
--
-- The current app persists the equivalent tables via Drizzle ORM (see
-- src/db/schema.ts) to keep Server Actions on a single trusted connection.
-- Use this file when you are ready to read/write invitations directly from
-- the browser or Edge Functions using Supabase's client libraries and RLS.
-- ============================================================================

create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users (id) on delete cascade,
  template_slug text not null,
  couple jsonb not null default '{}'::jsonb,
  events jsonb not null default '[]'::jsonb,
  story jsonb default '[]'::jsonb,
  gallery jsonb default '[]'::jsonb,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists set_invitations_updated_at on public.invitations;
create trigger set_invitations_updated_at
  before update on public.invitations
  for each row execute procedure public.set_updated_at();

create index if not exists invitations_owner_id_idx on public.invitations (owner_id);

alter table public.invitations enable row level security;

drop policy if exists "Invitations: owners manage their own" on public.invitations;
create policy "Invitations: owners manage their own"
  on public.invitations for all
  to authenticated
  using (owner_id = auth.uid())
  with check (owner_id = auth.uid());

drop policy if exists "Invitations: public can read published" on public.invitations;
create policy "Invitations: public can read published"
  on public.invitations for select
  to anon, authenticated
  using (published = true);

drop policy if exists "Invitations: admins manage all" on public.invitations;
create policy "Invitations: admins manage all"
  on public.invitations for all
  to authenticated
  using (public.is_admin());

-- ---------------------------------------------------------------------------

create table if not exists public.rsvps (
  id uuid primary key default gen_random_uuid(),
  invitation_id uuid not null references public.invitations (id) on delete cascade,
  guest_name text,
  attending boolean not null,
  guests integer not null default 1,
  message text,
  created_at timestamptz not null default now()
);

create index if not exists rsvps_invitation_id_idx on public.rsvps (invitation_id);

alter table public.rsvps enable row level security;

-- Guests (logged in or anonymous) may submit an RSVP to any published invitation.
drop policy if exists "RSVPs: anyone can respond to a published invitation" on public.rsvps;
create policy "RSVPs: anyone can respond to a published invitation"
  on public.rsvps for insert
  to anon, authenticated
  with check (
    exists (
      select 1 from public.invitations i
      where i.id = invitation_id and i.published = true
    )
  );

-- Only the invitation owner (or an admin) can read the responses.
drop policy if exists "RSVPs: owners read their invitation responses" on public.rsvps;
create policy "RSVPs: owners read their invitation responses"
  on public.rsvps for select
  to authenticated
  using (
    exists (
      select 1 from public.invitations i
      where i.id = invitation_id and i.owner_id = auth.uid()
    )
    or public.is_admin()
  );
