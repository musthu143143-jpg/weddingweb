# Supabase SQL

Run these in your Supabase project's **Dashboard → SQL Editor**, not in this
sandbox's local Postgres. They configure your actual Supabase project.

## Quick start

1. Open your Supabase project → **SQL Editor** → **New query**.
2. Paste the contents of **`000_full_schema.sql`** and click **Run**.
   This single file creates everything below in the right order and is
   safe to re-run.
3. Confirm `invitation-media` appears under **Storage** in your dashboard.

Prefer to run things incrementally? Use the numbered files in order instead:

| File | What it creates |
|---|---|
| `001_profiles.sql` | `user_role` enum, `public.profiles` table, RLS policies, and a trigger that auto-creates a profile (with role) the moment someone signs up |
| `002_invitations.sql` | `public.invitations` and `public.rsvps` reference tables with RLS (owner-only writes, public read for published invitations, public RSVP submission) |
| `003_storage.sql` | **Required** — creates the `invitation-media` Storage bucket and its access policies. Without this, the "Upload photos" / "Upload business logo" buttons in the app will fail. |

## How this fits the running app

This app talks to **two different Postgres databases** on purpose:

- **This sandbox's Postgres** (`DATABASE_URL`, queried through Drizzle ORM at
  `src/db/index.ts` / `src/db/schema.ts`) — holds the `profiles` table that
  powers the live `/dashboard`, `/reseller` and `/admin` pages you're using
  right now. Server Components and Server Actions read/write here directly.
- **Your Supabase project** — provides real user authentication
  (`@supabase/ssr`, see `src/lib/supabase/`) and, once you run
  `003_storage.sql`, real file storage for gallery photos and business
  logos (`src/lib/supabase/storage.ts`, `src/components/media/ImageUploader.tsx`).

`001_profiles.sql` and `002_invitations.sql` are provided as a **ready
reference schema** so the same tables also exist, RLS-secured, inside
Supabase Postgres — useful if you later want to query them directly from
the browser with the anon/publishable key, from Supabase Edge Functions, or
if you migrate the app to read/write Supabase Postgres directly instead of
the Drizzle connection. They are not required for the app you're previewing
today; **`003_storage.sql` is the one you need to run now** to enable image
uploads.

## Admin allow-list

`001_profiles.sql` includes an optional trigger that promotes emails in a
hard-coded array to `admin` on signup. Keep the array in sync with the
`ADMIN_EMAILS` environment variable used by the running app
(`src/lib/profile.ts`), or skip that trigger entirely — the app already
handles admin promotion for `ADMIN_EMAILS` at the database it actually
reads from.

## Storage layout

```
invitation-media/
  {userId}/gallery/{uuid}.jpg   ← Customize editor "Upload your photos"
  {userId}/logo/{uuid}.png      ← Reseller dashboard "Upload business logo"
```

The bucket is public for **reads** (wedding guests view photos without
logging in) and restricted for **writes** to the owner's own folder,
enforced by `storage.foldername(name)[1] = auth.uid()::text`.
