-- ============================================================================
-- 001_profiles.sql
-- Run this in your Supabase project's SQL Editor (Dashboard → SQL Editor).
--
-- Creates a Supabase-native "profiles" table keyed to auth.users, with Row
-- Level Security so every user can only read/update their own row, and a
-- trigger that automatically creates a profile the moment someone signs up
-- (reading the same metadata the app already sends: full_name,
-- requested_role, business_name).
--
-- NOTE ON CURRENT ARCHITECTURE: the running app persists profiles/roles via
-- Drizzle ORM to its own Postgres connection (see src/db/schema.ts) so that
-- Server Components/Actions can read and write with a single trusted
-- connection. This file is provided so the same schema also exists,
-- RLS-secured, inside your Supabase project — useful if you want to query
-- profiles directly from the browser with the anon key, from Edge
-- Functions, or if you migrate the app to read/write Supabase Postgres
-- directly in a later phase.
-- ============================================================================

-- 1. Role enum -----------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'user_role') then
    create type public.user_role as enum ('user', 'reseller', 'admin');
  end if;
end $$;

-- 2. Table -----------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  full_name text,
  role public.user_role not null default 'user',
  business_name text,
  phone text,
  logo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public.profiles is 'App-level profile & role for each Supabase auth user.';

-- 3. updated_at trigger ------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at
  before update on public.profiles
  for each row execute procedure public.set_updated_at();

-- 4. Auto-create a profile whenever a new auth user signs up ---------------
-- Mirrors the signUp() metadata sent from the app: full_name, requested_role,
-- business_name (see src/components/auth/AuthForm.tsx).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, role, business_name)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data ->> 'full_name',
    case
      when new.raw_user_meta_data ->> 'requested_role' = 'reseller' then 'reseller'::public.user_role
      else 'user'::public.user_role
    end,
    new.raw_user_meta_data ->> 'business_name'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 5. Admin allow-list promotion (optional) ----------------------------------
-- Mirrors the ADMIN_EMAILS server env var: promote matching emails to admin
-- automatically. Edit the array below to match your ADMIN_EMAILS value.
create or replace function public.promote_admin_allowlist()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  admin_emails text[] := array['owner@example.com']; -- keep in sync with ADMIN_EMAILS
begin
  if new.email = any (admin_emails) then
    update public.profiles set role = 'admin' where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_profile_created_promote_admin on public.profiles;
create trigger on_profile_created_promote_admin
  after insert on public.profiles
  for each row execute procedure public.promote_admin_allowlist();

-- 6. Row Level Security -------------------------------------------------------
alter table public.profiles enable row level security;

-- Security-definer helper avoids recursive-policy errors when checking role.
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

drop policy if exists "Profiles: read own" on public.profiles;
create policy "Profiles: read own"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

drop policy if exists "Profiles: admins read all" on public.profiles;
create policy "Profiles: admins read all"
  on public.profiles for select
  to authenticated
  using (public.is_admin());

drop policy if exists "Profiles: update own" on public.profiles;
create policy "Profiles: update own"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

drop policy if exists "Profiles: admins update all" on public.profiles;
create policy "Profiles: admins update all"
  on public.profiles for update
  to authenticated
  using (public.is_admin());
