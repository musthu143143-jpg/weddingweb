-- ============================================================================
-- 003_storage.sql
-- Run this in your Supabase project's SQL Editor to enable image uploads.
-- This is REQUIRED for the "Upload photos" / "Upload business logo" buttons
-- in the app (Customize editor gallery, Reseller business logo) to work —
-- they upload directly to this bucket using the browser Supabase client.
--
-- Creates one public bucket, "invitation-media", used for:
--   {userId}/gallery/...   couple-uploaded wedding gallery photos
--   {userId}/logo/...      reseller business logos
--
-- Files are namespaced by the uploader's auth.uid() so RLS can allow anyone
-- to VIEW media (wedding guests should never need to log in to see photos)
-- while only the owner may write inside their own folder.
-- ============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'invitation-media',
  'invitation-media',
  true,
  10485760, -- 10 MB per file
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif', 'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/x-m4a', 'audio/aac']
)
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Public read: anyone (including anonymous wedding guests) can view media.
drop policy if exists "invitation-media: public read" on storage.objects;
create policy "invitation-media: public read"
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'invitation-media');

-- Authenticated users may upload only inside a folder named after their own
-- user id, e.g. "3fa6.../gallery/photo.jpg".
drop policy if exists "invitation-media: owners can upload" on storage.objects;
create policy "invitation-media: owners can upload"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'invitation-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "invitation-media: owners can update" on storage.objects;
create policy "invitation-media: owners can update"
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'invitation-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "invitation-media: owners can delete" on storage.objects;
create policy "invitation-media: owners can delete"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'invitation-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
